const BaseConfig = {
    apiPath: 'http://106.14.199.230:8080/ythb'
}